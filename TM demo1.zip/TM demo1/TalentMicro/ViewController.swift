//
//  ViewController.swift
//  TalentMicro
//
//  Created by Arun Kumar on 16/12/20.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    

}

