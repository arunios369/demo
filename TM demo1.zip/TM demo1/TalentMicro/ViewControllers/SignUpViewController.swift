//
//  SignUpViewController.swift
//  TalentMicro
//
//  Created by Arun Kumar on 17/12/20.
//

import UIKit

class SignUpViewController: UIViewController {
    
    @IBOutlet weak var logo: UIImageView!
    
    @IBOutlet weak var signUpView: UIView!
    
    @IBOutlet weak var signUpLabel: UILabel!
    //first name
    @IBOutlet weak var firstNameLabel: UILabel!
    @IBOutlet weak var firstNameTF: UITextField!
    //last name
    @IBOutlet weak var lastNameLabel: UILabel!
    @IBOutlet weak var lastNameTF: UITextField!
    //email
    @IBOutlet weak var eMailLabel: UILabel!
    @IBOutlet weak var eMailTF: UITextField!
    //password
    @IBOutlet weak var passwordLabel: UILabel!
    @IBOutlet weak var passwordTF: UITextField!
    //confirm password
    @IBOutlet weak var confirmPasswordLabel: UILabel!
    @IBOutlet weak var confirmPasswordTF: UITextField!
  
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        firstNameTF.layer.cornerRadius = 15
        firstNameTF.layer.borderWidth = 0.5
        
        
    }

    @IBAction func signUpSubmitButton(_ sender: UIButton) {
        if firstNameTF.text == "" {
            alert(message: "please enter firstname")
        }else if lastNameTF.text == ""{
            alert(message: "please enter lastname")
        }else if (eMailTF.text?.isValidEmail())! {
            alert(message: "please enter valid email")
        }else if passwordTF.text == "" {
            alert(message: "please enter password")
        }else if confirmPasswordTF.text != passwordTF.text{
            alert(message: "password do not match")
        }else{
            UserDefaults.standard.set(self.eMailTF.text, forKey: "Email")
           UserDefaults.standard.set(self.passwordTF.text, forKey: "Password")
            let bookVC = storyboard?.instantiateViewController(withIdentifier: "SignInViewController")  as! SignInViewController
            self.navigationController?.pushViewController(bookVC, animated: true)
        }
        
    }
    
    func alert(message:String) {
        let alertController = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default) {
            UIAlertAction in
            
        }
        alertController.addAction(okAction)
        self.present(alertController, animated: true, completion: nil)
    }
  
    
}
extension String {
    func isValidEmail() -> Bool {
        // here, `try!` will always succeed because the pattern is valid
        let regex = try! NSRegularExpression(pattern: "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$", options: .caseInsensitive)
        return regex.firstMatch(in: self, options: [], range: NSRange(location: 0, length: count)) != nil
    }
}
