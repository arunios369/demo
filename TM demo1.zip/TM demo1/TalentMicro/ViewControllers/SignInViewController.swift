//
//  SignInViewController.swift
//  TalentMicro
//
//  Created by Arun Kumar on 17/12/20.
//

import UIKit

class SignInViewController: UIViewController {
    
    @IBOutlet weak var signInImage: UIImageView!
    
    @IBOutlet weak var signInLabel: UILabel!
    
    @IBOutlet weak var signInView: UIView!
    
    //email
    @IBOutlet weak var eMailLabel: UILabel!
    @IBOutlet var eMailTF: UITextField!
    
    //password
    @IBOutlet weak var passwordLabel: UILabel!
    @IBOutlet weak var passwordTF: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    //submit button
    @IBAction func signInSubmitButton(_ sender: UIButton) {
       
        if UserDefaults.standard.object(forKey: "Email") as! String != self.eMailTF.text!{
            alert(message: "please enter correct email")
        }else if UserDefaults.standard.object(forKey: "Password") as! String != self.passwordTF.text!{
            alert(message: "please enter correct password")
        }else{
            let bookVC = storyboard?.instantiateViewController(withIdentifier: "HomeViewController")  as! HomeViewController
            self.navigationController?.pushViewController(bookVC, animated: true)
        }
        
    }
    
    func alert(message:String) {
        let alertController = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default) {
            UIAlertAction in
            
        }
        alertController.addAction(okAction)
        self.present(alertController, animated: true, completion: nil)
    }

}
